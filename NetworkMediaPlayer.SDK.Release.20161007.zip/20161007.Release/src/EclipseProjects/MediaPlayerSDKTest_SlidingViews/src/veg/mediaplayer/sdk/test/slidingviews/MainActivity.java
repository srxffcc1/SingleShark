/*
 *
 * Copyright (c) 2010-2014 EVE GROUP PTE. LTD.
 *
 */

package veg.mediaplayer.sdk.test.slidingviews;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.view.inputmethod.InputMethodManager;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.*;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView.OnEditorActionListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;

import android.preference.PreferenceManager;
import veg.mediaplayer.sdk.MediaPlayer;
import veg.mediaplayer.sdk.MediaPlayer.PlayerNotifyCodes;
import veg.mediaplayer.sdk.MediaPlayer.PlayerState;
import veg.mediaplayer.sdk.MediaPlayerConfig;
import veg.mediaplayer.sdk.test.slidingviews.SurfacePageFragment.SurfacePageFragmentCallback;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;

public class MainActivity extends FragmentActivity implements SurfacePageFragmentCallback, MediaPlayer.MediaPlayerCallback
{
	public  static AutoCompleteTextView	edtIpAddress;
	public  static ArrayAdapter<String> edtIpAddressAdapter;
	public  static Set<String>			edtIpAddressHistory;
	private Button						btnConnect;
	private Button						btnHistory;

	private SharedPreferences 			settings;
    private SharedPreferences.Editor 	editor;

    //private boolean playing = false;
    private MainActivity mthis = null;
	//private Surface	surface = null;
 
	//private boolean	isFullScreen = false;

    //private static final int NUM_PAGES = 5;
    private MediaPlayer[] players = new MediaPlayer[4];

	private ViewPager mPager = null;
    private PagerAdapter mPagerAdapter = null;

    private Switch switchDecoderType = null;
	private Handler handler = new Handler() 
    {
	        @Override
	        public void handleMessage(Message msg) 
	        {
	        	PlayerNotifyCodes status = (PlayerNotifyCodes) msg.obj;
				if (status == PlayerNotifyCodes.CP_CONNECT_STARTING)
				{
					//player1.setVisibility(View.VISIBLE);
				}	
				if (status == PlayerNotifyCodes.PLP_CLOSE_STARTING)
				{
					//player1.setVisibility(View.INVISIBLE);
				}
				
		    	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
		        if (page == null) 
		        	return;
	
		        int position = page.getPageNumber();
				if (players[position].getState() == PlayerState.Closed)
					btnConnect.setText("Connect");
	        }
	};
	
	// callback from Native Player 
	@Override
	public int Status(int arg)
	{
    	Log.e(TAG, "Form Native Player status: " + arg);
		Message msg = new Message();
		msg.obj = PlayerNotifyCodes.forValue(arg);

		if (handler != null)
			handler.sendMessage(msg);
		
    	return 0;
    }

	@Override
	public int OnReceiveData(ByteBuffer buffer, int size, long pts) 
	{
		return 0;
	}
	
	@Override
	public void onSurfaceCreated(int position, Surface surface) 
	{
    	Log.d(TAG, "onSurfaceCreated: pos:" + position + ", surface: " + surface);
    	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
        if (page == null)
        	return;
        
    	players[position].setSurface(surface);
	}

	@Override
	public void onSurfaceChanged(int position, Surface surface, int newWidth, int newHeight) 
	{
    	Log.d(TAG, "onSurfaceChanged: pos:" + position + ", surface: " + surface + ", newWidth: " + newWidth + ", newHeight: " + newHeight);
    	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
        if (page == null)
        	return;
        
    	players[position].setSurface(surface, newWidth, newHeight);
		players[position].UpdateView();
	}

	@Override
	public void onSurfaceDestroyed(int position, Surface surface) 
	{
    	Log.d(TAG, "onSurfaceDestroyed: pos:" + position + ", surface: " + surface);
    	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
        if (page == null)
        	return;
        
    	players[position].setSurface(null);
	}

	@Override
	public void onSurfaceTouched(int position) 
	{
    	Log.d(TAG, "onSurfaceTouched: pos:" + position);
    	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
        if (page == null)
        	return;
        
        Log.d(TAG, "onSurfaceTouched state = " + players[position].getState());
//		if (players[position].getState() == PlayerState.Started)
//		{
//			players[position].Pause();
//		}
//		else
//			if (players[position].getState() == PlayerState.Paused)
//			{
//				players[position].Play();
//			}
	}

	protected float pxFromDp(float dp)
	{
		return (dp * getResources().getDisplayMetrics().density);
	}


    @SuppressLint("ClickableViewAccessibility")
	@Override
    public void onCreate(Bundle savedInstanceState) 
	{
		String  strUrl;

		setTitle(R.string.app_name);
		super.onCreate(savedInstanceState);

		setContentView(R.layout.main);
		mthis = this;
		
		for (int i = 0; i < players.length; i++) {
			players[i] = new MediaPlayer(this, false);
		}

		Log.e(TAG, "MediaPlayer instances: " + players.length);
		
		settings = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

		strUrl = settings.getString("connectionUrl", "rtsp://184.72.239.149/vod/mp4:BigBuckBunny_115k.mov");

		HashSet<String> tempHistory = new HashSet<String>();
		tempHistory.add("http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8");
		tempHistory.add("rtmp://184.72.239.149/vod/mp4:bigbuckbunny_450.mp4");
		tempHistory.add("rtsp://184.72.239.149/vod/mp4:BigBuckBunny_115k.mov");
		tempHistory.add("rtsp://rtmp.infomaniak.ch/livecast/latele");

		Set<String> savedHistory = settings.getStringSet("connectionHistory", tempHistory);
		edtIpAddressHistory = new HashSet<String>();
		edtIpAddressHistory.addAll(tempHistory);
		edtIpAddressHistory.addAll(savedHistory);

		this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN); 
	
		edtIpAddress = (AutoCompleteTextView)findViewById(R.id.edit_ipaddress);
		edtIpAddress.setText(strUrl);

		edtIpAddress.setOnEditorActionListener(new OnEditorActionListener() 
		{
			@Override
			public boolean onEditorAction(TextView v, int actionId,	KeyEvent event) 
			{
				if (event != null&& (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) 
				{
					InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					in.hideSoftInputFromWindow(edtIpAddress.getApplicationWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
					return true;
	
				}
				return false;
			}
		});

		btnHistory = (Button)findViewById(R.id.button_history);

		// Array of choices
		btnHistory.setOnClickListener(new View.OnClickListener() 
		{
			public void onClick(View v) 
			{
				InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				in.hideSoftInputFromWindow(MainActivity.edtIpAddress.getApplicationWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
				
				if (edtIpAddressHistory.size() <= 0)
					return;

				String urlHistory[] = {	};

				MainActivity.edtIpAddressAdapter = new ArrayAdapter<String>(MainActivity.this, R.layout.history_item, new ArrayList<String>(edtIpAddressHistory));
				MainActivity.edtIpAddress.setAdapter(MainActivity.edtIpAddressAdapter);
				MainActivity.edtIpAddress.showDropDown();
			}   
		});

        btnConnect = (Button)findViewById(R.id.button_connect);
        btnConnect.setOnClickListener(new View.OnClickListener() 
		{
			public void onClick(View v) 
			{
				String ConnectionUrl  = edtIpAddress.getText().toString();
				if (ConnectionUrl.isEmpty())
					return;
	
		    	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
		        if (page == null) 
		        	return;
	
		        int position = page.getPageNumber();
		        if (!edtIpAddressHistory.contains(ConnectionUrl))
					edtIpAddressHistory.add(ConnectionUrl);
	
	            Log.d(TAG, "btnConnect state = " + players[position].getState());
				if (players[position].getState() != PlayerState.Closed)
				{
			        players[position].Close();
//			    	if (page.getSurface() != null)
//			    	{
//			    		Log.e(TAG, "setSurface " + page.getSurface());
//			    		players[position].setSurface(page.getSurface());
//			    	}
					btnConnect.setText("Connect");
				}
				else
				{
			        MediaPlayerConfig conf = new MediaPlayerConfig();
			        //conf.setConnectionBufferingType(1);
			    	conf.setDecodingType(switchDecoderType.isChecked() ? 1 : 0);
			    	conf.setConnectionUrl(ConnectionUrl);
			    	//conf.setAspectRatioMode(21);
			    	//conf.setConnectionBufferingSize(20000);;
			    	if (ConnectionUrl.contains("udp://"))
			    	{
			    		//conf.setConnectionNetworkProtocol(0);
			    	}
			    	conf.setConnectionUrl(ConnectionUrl);
			    	
			    	if (page.getSurface() != null)
			    	{
			    		Log.e(TAG, "setSurface " + page.getSurface());
			    		players[position].setSurface(page.getSurface());
			    	}
			    	
//			    	conf.setFFRate(0);
//			    	conf.setDropOnFastPlayback(1);
			    	players[position].Open(conf, mthis);
			    	btnConnect.setText("Disconnect");
				}
			}   
		});

        switchDecoderType = (Switch) findViewById(R.id.switch_decoder_type);
        
        // Instantiate a ViewPager and a PagerAdapter.
        mPager = (ViewPager) findViewById(R.id.surfacePager);
        mPagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        mPager.setAdapter(mPagerAdapter);
        mPager.setOnPageChangeListener(new OnPageChangeListener() 
        {
            @Override
            public void onPageSelected(int position) 
            {
                Log.d(TAG, "onPageSelected, position = " + position);
				if (players[position].getState() == PlayerState.Closed)
				{
					btnConnect.setText("Connect");
				}
				else
				{
			    	btnConnect.setText("Disconnect");
				}
				
				for (int i = 0; i < players.length; i++) 
				{
					players[i].toggleMute(!(position == i));
				}
				
				switchDecoderType.setChecked(players[position].getConfig().getDecodingType() == 1);
				
//			   	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
//		        if (page == null)
//		        	return;
//		        
//	    		players[0].setSurface(page.getSurface());
           }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) 
            {
            }

            @Override
            public void onPageScrollStateChanged(int state) 
            {
            }
        });
        
	}

    @Override
    public void onConfigurationChanged(Configuration newConfigure)
    {
    	super.onConfigurationChanged(newConfigure);
    	
    	SurfacePageFragment page = (SurfacePageFragment)mPager.getAdapter().instantiateItem(mPager, mPager.getCurrentItem());
        if (page == null) 
        	return;

        int position = page.getPageNumber();
		players[position].UpdateView();
    }
    
    @Override
    public void onBackPressed() 
    {
        if (mPager.getCurrentItem() == 0) 
        {
            super.onBackPressed();
        } 
        else 
        {
            mPager.setCurrentItem(mPager.getCurrentItem() - 1);
        }
    }

    protected void onPause()
	{
		Log.e(TAG, "onPause()");
		super.onPause();

		editor = settings.edit();
		editor.putString("connectionUrl", edtIpAddress.getText().toString());
		editor.putStringSet("connectionHistory", edtIpAddressHistory);
		editor.commit();
	}

	@Override
  	protected void onResume() 
	{
		Log.e(TAG, "onResume()");
		super.onResume();
  	}

  	@Override
	protected void onStart() 
  	{
      	Log.e(TAG, "onStart()");
		super.onStart();
	}

  	@Override
	protected void onStop() 
  	{
  		Log.e(TAG, "onStop()");
		super.onStop();
	}

  	@Override
  	public void onWindowFocusChanged(boolean hasFocus) 
  	{
  		Log.e(TAG, "onWindowFocusChanged(): " + hasFocus);
  		super.onWindowFocusChanged(hasFocus);
  	}

  	@Override
  	public void onLowMemory() 
  	{
  		Log.e(TAG, "onLowMemory()");
  		super.onLowMemory();
  	}

  	@Override
  	protected void onDestroy() 
  	{
  		Log.e(TAG, "onDestroy()");
		for (int i = 0; i < players.length; i++) {
			players[i].Close();
		}

		super.onDestroy();
   	}	
	
    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter 
    {
        public ScreenSlidePagerAdapter(FragmentManager fm) 
        {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) 
        {
            return SurfacePageFragment.create(position, mthis);
        }

        @Override
        public int getCount() 
        {
            return players.length;
        }
    }
    
	private static final String TAG = "MediaPlayerSDKTest.SlidingViews";

}
